import React from 'react';

const NavBar = () => {
    return (
        <div>
            <span>This is header</span>
        </div>
    );
};

export default NavBar;