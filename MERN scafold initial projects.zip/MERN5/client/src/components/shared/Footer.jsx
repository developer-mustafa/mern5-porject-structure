import React from 'react';

const Footer = () => {
    return (
        <div>
            <span>This is footer</span>
        </div>
    );
};

export default Footer;