import React from 'react';

const ListLoader = () => {
    return (
        <div>

        </div>
    );
};

export default ListLoader;