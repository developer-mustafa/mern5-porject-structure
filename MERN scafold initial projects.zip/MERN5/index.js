const app=require("./app");
const PORT=3030;
app.listen(PORT,function () {
    console.log("App Run @3030")
})

