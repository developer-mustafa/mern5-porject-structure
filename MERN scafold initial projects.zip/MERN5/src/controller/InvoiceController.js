exports.CreateInvoice=async(req,res)=>{
    // SSL Commarce--> Third Party
    // Data Base Operation
    // MongoDB
    // File Read Write
    return res.status(200).json({total:"1000BDT",vat:"50BDT",payable:"1050BDT"})
}