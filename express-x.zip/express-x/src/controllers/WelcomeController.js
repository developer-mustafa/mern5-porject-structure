export const Welcome=async(req,res)=>{
    return res.json({
        data:"Welcome"
    })
}

export const Welcome1=async(req,res)=>{
    return res.status(200).json({
        data:"Welcome1"
    })
}

export const Welcome2=async(req,res)=>{
    return res.status(200).json({
        data:"Welcome2"
    })
}
