import app from "./app.js";
app.listen(4000,()=>{
    console.log("Running...")
})