

function openSidebar(){
    document.querySelector(".sidebar").style.width = "250px";
}

function closeSidebar(){
    document.querySelector(".sidebar").style.width = "0";
}