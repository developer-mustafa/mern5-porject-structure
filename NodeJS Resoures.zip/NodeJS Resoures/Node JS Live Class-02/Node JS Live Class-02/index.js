// Working With URL Module 

/*
const url=require('url')// ES5 
const myURL='http://ostad.app/api/v1/product/delete?userID=1&productID=2' // Base+Path+Query
const u= url.parse(myURL,true);

console.log(u.host);
console.log(u.pathname);
console.log(u.search)
*/





























// Read File 
/*
const http=require('http');
const fs=require('fs');
http.createServer(function(req,res){
    
    fs.readFile('demo.text',function(error,data){
        res.write(data);
        res.end();
    })


}).listen(4040,function(){
    console.log("Server Running....");
})
*/






















// Create File 
/*
const http=require('http');
const fs=require('fs');
http.createServer(function(req,res){
    

    fs.writeFile('demo1.text','Hello...',function(err){
        if(err){
            res.end("File Writing Fail")
        }else{
            res.end("File Write Success")
        }
    });


}).listen(4040,function(){
    console.log("Server Running....");
})
*/























// Update File 
/*
const http=require('http');
const fs=require('fs');
http.createServer(function(req,res){
    

    fs.appendFile('demo1.text','Hello...Hello...',function(err){
        if(err){
            res.end("File Update Fail")
        }else{
            res.end("File Update Success")
        }
    });

}).listen(4040,function(){
    console.log("Server Running....");
})
*/


























// Delete File 
/*
const http=require('http');
const fs=require('fs');
http.createServer(function(req,res){
    

    fs.unlink('demo1.text',function(err){
        if(err){
            res.end("File Delete Fail")
        }else{
            res.end("File Delete Success")
        }
    });

}).listen(4040,function(){
    console.log("Server Running....");
})

*/



// Rename 

/*
const http=require('http');
const fs=require('fs');
http.createServer(function(req,res){
    
    fs.rename('demo.text','new_demo.text',function(err){
        if(err){
            res.end("File Rename Fail")
        }else{
            res.end("File Rename Success")
        }
    });

}).listen(4040,function(){
    console.log("Server Running....");
})
*/


























// Node JS Debugging 
/*
const http=require('http');
const fs=require('fs');
http.createServer(function(req,res){
    
    let a=20;
    let b=30;
    let c=40;
    let d=50;

    try{
        let sum=a+b+c+d+f;
    }catch(err){
        console.log(err)
    }

    res.end(sum);


}).listen(4040,function(){
    console.log("Server Running....");
})
*/
