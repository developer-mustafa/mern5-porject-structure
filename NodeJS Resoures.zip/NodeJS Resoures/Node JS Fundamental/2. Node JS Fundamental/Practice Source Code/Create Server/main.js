var http=require('http');
var URL=require('url');
var URL=require('url');
var server=http.createServer(function (req,res) {

});

server.listen(5050);
console.log("Server Run Success");



