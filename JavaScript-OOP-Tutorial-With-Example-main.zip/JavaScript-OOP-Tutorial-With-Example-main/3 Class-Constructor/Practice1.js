class Person {
    constructor() {
        console.log('I am a constructor')
    }
}
const person1 = new Person();
