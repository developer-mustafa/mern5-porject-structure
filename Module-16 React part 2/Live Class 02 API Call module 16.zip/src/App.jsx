import ReadPage from "./pages/ReadPage.jsx";

const App = () => {
    return (
        <div>
            <ReadPage/>
        </div>
    );
};
export default App;